from fastapi import FastAPI, HTTPException
app = FastAPI()

SESSIONS = {}

@app.get("/api/health")
def health():
    return {"ok": True}

@app.post("/api/login")
def login(user_id: str, password: str):
    if password != "badge1234":
        raise HTTPException(401, "비밀번호가 맞지 않습니다.")
    SESSIONS[user_id] = {"role": "viewer"}
    return {"token": "ok"}

@app.get("/api/badges")
def badges():
    return {"badges": []}
