from fastapi import FastAPI
app = FastAPI()

@app.get("/api/health")
def health():
    return {"ok": True}

@app.get("/api/items")
def items():
    return {"items": ["A4용지", "볼펜", "포스트잇"]}
