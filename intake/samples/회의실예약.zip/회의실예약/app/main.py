"""회의실 예약 — 층별 회의실을 시간 단위로 잡는다.

로그인은 포털이 앞단에서 처리한다. 이 앱은 X-User-Id 헤더만 읽는다.
"""
import os
from fastapi import FastAPI, Request, HTTPException
import httpx

app = FastAPI()

def _dev(): return str(os.getenv("DEV_MODE","false")).lower() in ("1","true","yes")

def user(request: Request) -> dict:
    """포털이 붙여 준 헤더에서 사용자를 읽는다."""
    uid = request.headers.get("X-User-Id")
    if not uid:
        if _dev(): return {"id":"hong","role":"admin"}
        raise HTTPException(401, "포털을 통해 접속해 주세요.")
    return {"id": uid, "role": request.headers.get("X-User-Role","user")}

@app.get("/api/health")
def health():
    """살아 있는지 확인하는 주소."""
    return {"ok": True}

@app.get("/api/rooms")
def rooms(request: Request):
    """예약 가능한 회의실 목록."""
    user(request)
    return {"rooms": ["3F 회의실", "4F 회의실1", "4F 회의실2"]}

async def register():
    """뜰 때 포털에 자기를 등록한다."""
    base = os.getenv("PORTAL_API_URL","")
    if not base: return
    async with httpx.AsyncClient(timeout=5) as c:
        await c.post(f"{base}/api/services/register",
                     json={"id":"meeting-room","name":"회의실 예약","url":"/meeting-room/"},
                     headers={"X-Service-Token": os.getenv("AUDIT_TOKEN","")})

async def audit(action: str, who: str):
    """포털 이력으로 보낸다."""
    base = os.getenv("PORTAL_API_URL","")
    if not base: return
    async with httpx.AsyncClient(timeout=5) as c:
        await c.post(f"{base}/api/audit", json={"action":action,"user":who},
                     headers={"X-Service-Token": os.getenv("AUDIT_TOKEN","")})
